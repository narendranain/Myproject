Requirements  to run this project
1.	Java8
2.	Eclipse (Oxygen)
3. Tomcat Server 8.0
4.	Oracle11g


Steps to run the project
1.	Make required changes into the string (databasepath) in files(singup.java,AddAdmin.java,AddQue.java,LoginDao.java,Stlogindao.java).
It is hard coded .
2.	Open file DataBase.txt  (   OnlineExam\Database.txt )and Execute the queries.
3.	Now add student using signup option.
4.	Now  student start test .
5.	We can add admin (after once login into admin by using { admin,admin})





